#!/bin/bash

# Ako se program ne startuje, onda Vam je python interpreter na drugoj lokaciji, ili Vam nedostaje
PYTHON_Interpreter=/usr/bin/python3

PYTHON_SCRIPT=./start-game.py


$PYTHON $PYTHON_SCRIPT

